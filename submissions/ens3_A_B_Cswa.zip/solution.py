"""Connectome submission: ensamble de N GRUs de 2 capas (promedio simple), todo en un kernel numba.

Archivos: solution.py + weights.npz. Cada GRU trae su propio normalizador (mean/std) y estado
(h0, h1). Pesos apilados como globales (N, ...); numba los embebe como constantes al compilar.
Determinista. Solo numpy + numba.
"""
import math
import os
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
from numba import njit

N_FEATURES = 112
_W = np.load(Path(__file__).resolve().parent / "weights.npz", allow_pickle=False)
N_MODELS = int(_W["n_models"])
HIDDEN = int(_W["hidden"])                                    # H máximo (los arrays están rellenados a este tamaño)
HID = np.ascontiguousarray(_W["hidden_per_model"], dtype=np.int64)  # (N,) H real de cada modelo
# (N, ...) contiguos
MEAN = np.ascontiguousarray(_W["mean"], dtype=np.float32)      # (N, 112)
STD = np.ascontiguousarray(_W["std"], dtype=np.float32)        # (N, 112)
W1 = np.ascontiguousarray(_W["W1"], dtype=np.float32)          # (N, 3H, 112)
R1 = np.ascontiguousarray(_W["R1"], dtype=np.float32)          # (N, 3H, H)
WB1 = np.ascontiguousarray(_W["Wb1"], dtype=np.float32)        # (N, 3H)
RB1 = np.ascontiguousarray(_W["Rb1"], dtype=np.float32)
W2 = np.ascontiguousarray(_W["W2"], dtype=np.float32)          # (N, 3H, H)
R2 = np.ascontiguousarray(_W["R2"], dtype=np.float32)
WB2 = np.ascontiguousarray(_W["Wb2"], dtype=np.float32)
RB2 = np.ascontiguousarray(_W["Rb2"], dtype=np.float32)
WO = np.ascontiguousarray(_W["Wo"], dtype=np.float32)          # (N, H, 2)
BO = np.ascontiguousarray(_W["bo"], dtype=np.float32)          # (N, 2)
WEIGHTS = np.ascontiguousarray(_W["model_weights"], dtype=np.float32)  # (N,) suman 1
CLIP = np.ascontiguousarray(_W["input_clip"], dtype=np.float32)       # (N,) recorte de z por modelo (inf = sin recorte)

FAST = {"reassoc", "contract", "arcp", "afn", "nsz"}


@njit(fastmath=FAST)
def _gru_step(x, D, h, H, W, R, Wb, Rb, gi, gh):
    for row in range(3 * H):
        s = Wb[row]
        for k in range(D):
            s += W[row, k] * x[k]
        gi[row] = s
        t = Rb[row]
        for k in range(H):
            t += R[row, k] * h[k]
        gh[row] = t
    for j in range(H):
        z = 1.0 / (1.0 + math.exp(-(gi[j] + gh[j])))
        r = 1.0 / (1.0 + math.exp(-(gi[H + j] + gh[H + j])))
        n = math.tanh(gi[2 * H + j] + r * gh[2 * H + j])
        h[j] = (1.0 - z) * n + z * h[j]


@njit(fastmath=FAST)
def step_row(x, h0, h1, z, gi, gh, out):
    """Una fila: actualiza h0[N,H], h1[N,H] in-place; out = promedio ponderado de las N salidas."""
    o0 = 0.0
    o1 = 0.0
    for m in range(N_MODELS):
        c = CLIP[m]
        for j in range(N_FEATURES):
            v = (x[j] - MEAN[m, j]) / STD[m, j]
            if v > c:
                v = c
            elif v < -c:
                v = -c
            z[j] = v
        H = HID[m]
        _gru_step(z, N_FEATURES, h0[m], H, W1[m], R1[m], WB1[m], RB1[m], gi, gh)
        _gru_step(h0[m], H, h1[m], H, W2[m], R2[m], WB2[m], RB2[m], gi, gh)
        g0 = BO[m, 0]
        g1 = BO[m, 1]
        for k in range(H):
            g0 += h1[m, k] * WO[m, k, 0]
            g1 += h1[m, k] * WO[m, k, 1]
        o0 += WEIGHTS[m] * g0
        o1 += WEIGHTS[m] * g1
    out[0] = o0
    out[1] = o1


class PredictionModel:
    def __init__(self):
        self.h0 = np.zeros((N_MODELS, HIDDEN), np.float32)
        self.h1 = np.zeros((N_MODELS, HIDDEN), np.float32)
        self.z = np.zeros(N_FEATURES, np.float32)
        self.gi = np.zeros(3 * HIDDEN, np.float32)
        self.gh = np.zeros(3 * HIDDEN, np.float32)
        self.out = np.zeros(2, np.float32)
        self.seq_ix = None
        step_row(np.zeros(N_FEATURES, np.float32), self.h0, self.h1, self.z, self.gi, self.gh, self.out)  # compila ahora
        self._reset()

    def _reset(self):
        self.h0[:] = 0.0
        self.h1[:] = 0.0

    def predict(self, data_point):
        if data_point.seq_ix != self.seq_ix:
            self.seq_ix = data_point.seq_ix
            self._reset()
        x = np.asarray(data_point.state, dtype=np.float32)
        step_row(x, self.h0, self.h1, self.z, self.gi, self.gh, self.out)
        if not data_point.need_prediction:
            return None
        return self.out.copy()
